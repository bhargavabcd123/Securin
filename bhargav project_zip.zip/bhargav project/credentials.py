##database user name 
user = "root"
#URL-encoded '@' as '%40'
password = "Gd%402004dec"
##database name 
db_name = "cve_db"
##nvd api link 
base_url = "https://services.nvd.nist.gov/rest/json/cves/2.0"
##time gap in days 
update_time_interval = 7 

